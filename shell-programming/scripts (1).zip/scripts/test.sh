#!/bin/sh

ls abc

echo "\$?:$?"

if [ $? -eq 0 ]
then
	echo "ls command success"
else
	echo "ls command fails"
fi
