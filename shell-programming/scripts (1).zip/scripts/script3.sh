#!/bin/sh

# Shell parameters and command line arguments

IFS='_'
echo "Shell name:\$0=$0"

echo "shell 1st argument:\$1=$1"
echo "shell 2nd argument:\$2=$2"
echo "shell no. of arguemnts:\$#=$#"

echo "shell pid no:\$$=$$"
echo "list all paramters:\$*=$*"
echo "list all paramters:\$@=$@"



