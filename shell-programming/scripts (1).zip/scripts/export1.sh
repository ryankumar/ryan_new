#!/bin/sh

#echo "user name:$USER"

# the below command exports all the variables thereafter

var2=34

set -a


var1=12


./export2.sh

