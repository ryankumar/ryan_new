#!/bin/sh


ping -c 3 www.google.com > /dev/null 2> /dev/null

if [ $? -eq 0 ]
then
	echo "Internet is working"
else
	echo "Internet is not working"
fi
