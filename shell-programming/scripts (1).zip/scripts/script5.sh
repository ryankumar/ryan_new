#!/bin/sh

# This shell example shows that how to use Proper ERROR handling in shell

#echo kernel > 123

ls $1 > /dev/null 2> /dev/null


#echo "\$?:$?"

if [ $? -eq 0 ]
then
	echo "ls command SUCCESS"
else
	echo "ls command FAIL"
	exit 4
fi

exit 0

#ls xyz
#echo "ls xyz command status: $?"


#echo kernel > 123
#echo "ls 123 command status: $?"
