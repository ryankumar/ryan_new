#!/bin/sh

#Hello world script program

export test=abc

echo "Hello World"
read var
echo "var value:$var"
echo "test value:$test"

test=xyz
echo "test value:$test"
