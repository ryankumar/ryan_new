#include <stdio.h>

void fun1 (int , int, int, int, int, int, int  );

main ()
{
//int x,y;
//x=4;
//y=5;

fun1 (1,2,3,4,5,6,7);

}


void fun1 (int a, int b,int c ,int d, int e,int f, int g )
{
	int x;
	x = a;
}

