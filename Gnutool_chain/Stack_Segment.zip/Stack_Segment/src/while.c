main ()
{
getchar();
system("ls -l");
while(1);

}
