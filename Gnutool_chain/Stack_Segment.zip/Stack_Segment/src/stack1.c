#include <stdio.h>

void func1(void);

main ()
{
int i=3;
func1();
}

void func1(void)
{
int i=5;
}
