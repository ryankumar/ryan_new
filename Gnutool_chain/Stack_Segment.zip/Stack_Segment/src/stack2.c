#include <stdio.h>

void fun1 (int , int );

main ()
{
int i=3;
fun1(1, 2);
}


void fun1 (int a, int b)
{
	int x;
	x = a;
}

