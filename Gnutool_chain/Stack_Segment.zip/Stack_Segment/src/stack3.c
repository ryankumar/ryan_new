#include <stdio.h>

void fun1 (int , int );

main ()
{
int x,y;
x=4;
y=5;

fun1 (x, y);

}


void fun1 (int a, int b)
{
	int x;
	x = a;
}

