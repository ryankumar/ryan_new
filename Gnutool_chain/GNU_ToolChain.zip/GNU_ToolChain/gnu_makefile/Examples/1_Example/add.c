#include <stdio.h>

int add (int a ,int b)
{
printf ("add function\n");
return (a+b);

}


