#include <stdio.h>
#include "include.h"

main ()
{

printf ("Hello\n");
printf ("add 2 numbers:%d\n",add(2,4));
printf ("sub 2 numbers:%d\n",sub(4,4));


}
