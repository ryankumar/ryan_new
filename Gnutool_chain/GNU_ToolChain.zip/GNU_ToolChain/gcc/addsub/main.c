#include<stdio.h>
#include "myheader.h"

int main()
{

printf ("Add Results:%d\n",add(5,3));
printf ("Sub Results:%d\n",sub(5,3));

return 0;
}


