#include<stdio.h>
#include<include.h>

main ()
{

printf ("add result:%d\n",add(20,10));
printf ("sub result:%d\n",sub(20,10));


}
