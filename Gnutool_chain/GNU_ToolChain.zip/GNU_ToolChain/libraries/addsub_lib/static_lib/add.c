#include<stdio.h>


int add(int a, int b)
{
printf ("This is add function test\n");
return a+b;
}
