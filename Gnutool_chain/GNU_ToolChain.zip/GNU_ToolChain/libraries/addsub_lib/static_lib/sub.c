#include<stdio.h>


int sub(int a, int b)
{
printf ("This is sub function\n");
return a-b;
}
